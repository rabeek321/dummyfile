import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderComponent } from './header.component';
import { RouterTestingModule } from '@angular/router/testing';
import { MessageSubscriptionService } from '../../services/message-subscription.service';
import { Router } from '@angular/router';
import { of } from 'rxjs';
describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;
  let api: MessageSubscriptionService;
  let mockRouter = {
    navigate: jasmine.createSpy('navigate')
  };
  const mockUserService = {
    isValidUser: false,
    setValidUser: (flag: boolean) => { mockUserService.isValidUser = flag; },
    currentUser: {
      customerName: 'Rabeek',
      customerId: 12345,
    },
    validUser: () => mockUserService.isValidUser,
    loggedUser: () => {
      return mockUserService.currentUser;
    },
    modalConfig: () => ({
      message: '',
      modalShow: ''
    }),
    getMessage() {
      return of({
        userName: 'Rabeek',
        role: 'ADMIN'
      });
    }
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [HeaderComponent],
      imports: [RouterTestingModule.withRoutes([])],
      providers: [
        {
          provide: MessageSubscriptionService, useValue: mockUserService
        },
      ]
    })
      .compileComponents();
    api = TestBed.get(MessageSubscriptionService);
    mockRouter = TestBed.get(Router);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should check ngOnInit', () => {
    component.ngOnInit();
    expect(component).toBeTruthy();
  });
  it('should check logout', () => {
    sessionStorage.clear();
    expect(api.messageService()).toBeTruthy();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/login']);
  });
  it('should check loggedin user', () => {
    const response = {
      userName: 'Rabeek',
      role: 'ADMIN'
    };
    component.getLoginUser();
    const currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
    expect(api.getMessage()).toBeTruthy();
    expect(currentUser).toEqual(response);
  });
});
