import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminComponent } from './admin.component';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { PrimengModule } from '../../shared/primeng/primeng.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpserviceService } from '../../services/httpservice.service';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import { of } from 'rxjs';

describe('AdminComponent', () => {
  let component: AdminComponent;
  let fixture: ComponentFixture<AdminComponent>;
  let api: HttpserviceService;
  let mockRouter = {
    navigate: jasmine.createSpy('navigate')
  };
  const mockUserService = {
    isValidUser: false,
    setValidUser: (flag: boolean) => { mockUserService.isValidUser = flag; },
    currentUser: {
      customerName: 'Rabeek',
      customerId: 12345,
    },
    validUser: () => mockUserService.isValidUser,
    loggedUser: () => {
      return mockUserService.currentUser;
    },
    modalConfig: () => ({
      message: '',
      modalShow: ''
    }),
    getPlans() {
      return of({
        statusCode: 200,
        planDetails: [{
          planId: 111,
          fromTime: '2020-02-17 16:12:30',
          toTime: '2020-02-17 18:12:30',
          planType: 'Gold',
        }]
      });
    },
    planSubmit() {
      return of({
        statusCode: 200,
        message: 'Plan Added Successfully'
      });
    }
  };
  const formBuilder: FormBuilder = new FormBuilder();
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AdminComponent],
      imports: [SharedModule, PrimengModule, BrowserAnimationsModule, HttpClientTestingModule, RouterTestingModule],
      providers: [
        {
          provide: HttpserviceService, useValue: mockUserService
        },
        { provide: FormBuilder, useValue: formBuilder },
        {
          provide: Router, useValue: mockRouter
        },
        DatePipe
      ]
    })
      .compileComponents();
    api = TestBed.get(HttpserviceService);
    mockRouter = TestBed.get(Router);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should check ngOnInit form creation', () => {
    component.ngOnInit();
    component.planForm = new FormGroup({
      fromDate: new FormControl('', [Validators.required]),
      fromTime: new FormControl('', [Validators.required]),
      toTime: new FormControl('', [Validators.required]),
      planType: new FormControl('', [Validators.required])
    });
    expect(component.planForm.valid).toBeFalsy();
  });
  it('should add new plan', () => {
    component.addNewPlan();
    component.addSlot = true;
    component.planForm.reset();
    expect(component).toBeTruthy();
  });
  it('should submit new plan', () => {
    const postObj = {
      // tslint:disable-next-line: max-line-length
      fromTime: component.planForm.controls.fromDate.setValue('2020-02-17') + ' ' + component.planForm.controls.fromTime.setValue('16:12:30'),
      toTime: component.planForm.controls.fromDate.setValue('2020-02-17') + ' ' + component.planForm.controls.toTime.setValue('18:12:30'),
      planType: component.planForm.controls.planType.setValue('Gold')
    };
    component.submitPlan();
    expect(api.planSubmit(postObj)).toBeTruthy();
  });
  it('should get all plan', () => {
    component.getAllPlans();
    // expect(api.getPlans()).toBeTruthy();
  });
});
