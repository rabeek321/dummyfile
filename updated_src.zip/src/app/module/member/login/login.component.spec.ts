import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginComponent } from './login.component';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { SharedModule } from '../../../shared/shared.module';
import { PrimengModule } from '../../../shared/primeng/primeng.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpserviceService } from '../../../services/httpservice.service';
import { Router } from '@angular/router';
import { of } from 'rxjs';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let api: HttpserviceService;
  let mockRouter = {
    navigate: jasmine.createSpy('navigate')
  };
  const mockUserService = {
    isValidUser: false,
    setValidUser: (flag: boolean) => { mockUserService.isValidUser = flag; },
    currentUser: {
      customerName: 'Rabeek',
      customerId: 12345,
    },
    validUser: () => mockUserService.isValidUser,
    loggedUser: () => {
      return mockUserService.currentUser;
    },
    modalConfig: () => ({
      message: '',
      modalShow: ''
    }),
    checkLogin(data: object) {
      return of({
        statusCode: 200,
        userName: 'Rabeek',
        role: 'ADMIN'

      });
    }
  };
  const formBuilder: FormBuilder = new FormBuilder();
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LoginComponent],
      imports: [SharedModule, PrimengModule, BrowserAnimationsModule, HttpClientTestingModule, RouterTestingModule],
      providers: [
        {
          provide: HttpserviceService, useValue: mockUserService
        },
        { provide: FormBuilder, useValue: formBuilder },
        {
          provide: Router, useValue: mockRouter
        }
      ]
    })
      .compileComponents();
    api = TestBed.get(HttpserviceService);
    mockRouter = TestBed.get(Router);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should check ngOnInit Valid User and form creation', () => {
    component.ngOnInit();
    const currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
    if (!api.validUser()) {
      expect(mockRouter.navigate).toHaveBeenCalledWith(['/login']);
    } else {
      expect(mockRouter.navigate).toHaveBeenCalledWith(['/admin']);
    }
    component.loginForm = new FormGroup({
      username: new FormControl('', [Validators.required]),
      password: new FormControl('', [Validators.required])
    });
    expect(component.loginForm.valid).toBeFalsy();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/login']);
  });
  it('it shoud validate logged in user', () => {
    const response = {
      userName: 'Rabeek',
      role: 'ADMIN'
    };
    const postObj = {
      mobileNumber: component.loginForm.controls.username.setValue('987654321'),
      password: component.loginForm.controls.password.setValue('12345')
    };
    component.validateLogin();
    const currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
    expect(api.checkLogin(postObj)).toBeTruthy();
    expect(currentUser).toEqual(response);
    expect(component.loader).toBeFalsy();
  });
  // it('it shoud check the role', () => {
  //   const response = {
  //     statusCode: 200,
  //     userName: 'Rabeek',
  //     role: 'ADMIN'
  //   };
  //   const postObj = {
  //     mobileNumber: component.loginForm.controls.username.setValue('987654321'),
  //     password: component.loginForm.controls.password.setValue('12345')
  //   };
  //   component.validateLogin();

  //   // const currentUser = JSON.parse(sessionStorage.getItem('currentUser')).role;
  //   // expect(currentUser).toBe('ADMIN');
  // });
});
