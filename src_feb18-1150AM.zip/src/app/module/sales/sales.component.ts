import { Component, OnInit, ElementRef } from '@angular/core';
import { HttpserviceService } from '../../services/httpservice.service';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-sales',
  templateUrl: './sales.component.html',
  styleUrls: ['./sales.component.css'],
  providers: [DatePipe]
})

export class SalesComponent implements OnInit {

  displayBasic = false;
  planDetails: PlanDetails[];
  slotDetails: SlotDetails[];
  selectedSlot: SlotDetails;
  selectedPlan;

  hours;
  mins;
  secs;
  selectedHours;
  selectedMins;
  selectedSens;


  selectedtoHours;
  selectedtoMins;
  selectedtoSens;

  tohours;
  tomins;
  tosecs;

  toDateLess = false;
  constructor(
    private httpService: HttpserviceService,
    private date: DatePipe,
    private elementRef: ElementRef,
    private router: Router
  ) { }

  ngOnInit() {
    const date = new Date();
    const fd = new Date();
    fd.setDate(18);
    fd.setHours(10, 23, 50);
    const td = new Date();
    td.setDate(18);
    td.setHours(14, 24, 53);
    const seconds = date.getSeconds();
    const minutes = date.getMinutes();
    const hour = date.getHours();

    this.getAllPlans();
    this.elementRef.nativeElement.ownerDocument.body.style.background = '';
    if (!this.httpService.validUser()) {
      this.router.navigate(['/login']);
    } else {
      this.router.navigate(['/sales']);
    }
  }

  getAllPlans() {
    this.httpService.getPlans().subscribe(res => {
      console.log(res);
      this.planDetails = res.planDetails;
    }
    );
  }

  getSlotDetails(plan) {

    this.httpService.getSlot(plan.planId).subscribe(
      (res) => {
        if (res.statusCode === 202) {
          const slotList = [{
            slotId: 0,
            fromTime: plan.fromTime,
            toTime: plan.toTime,
            status: 'pending'
          }];
          this.slotDetails = slotList;
        } else {
          this.slotDetails = res.slotDetails;
        }

      }
    );
  }

  showBasicDialog(slot: SlotDetails, planId) {
    this.selectedPlan = planId;
    this.selectedSlot = slot;

    this.hours = this.availableHours(slot.fromTime, slot.toTime);
    this.tohours = this.hours;
    console.log(this.hours);
    this.displayBasic = true;
  }
  availableHours(fromTime, toTime) {
    const hours = [];
    const converttoTime = new Date(toTime);
    const convertfromTime = new Date(fromTime);
    const arryaLength = converttoTime.getHours() - convertfromTime.getHours();
    let startTime = convertfromTime.getHours();
    for (let index = 0; index <= arryaLength; index++) {
      const booking = {
        hours: startTime
      };
      hours.push(booking);
      startTime++;
    }
    console.log(hours);
    return hours;
  }
  minSelection(event) {
    const hour = event.value;
    this.mins = this.timeprocessing(hour.hours);
  }

  tominSelection(event) {
    const hour = event.value;
    this.tomins = this.timeprocessing(hour.hours);
  }


  timeprocessing(time) {
    let startMin: any = 1;
    let totalMin = 60;
    let arrayLength;
    const result = [];
    const selectedTime = new Date(this.selectedSlot.fromTime).getHours();
    if (selectedTime === time) {
      startMin = new Date(this.selectedSlot.fromTime).getMinutes();
    }
    if (new Date(this.selectedSlot.fromTime).getHours() === new Date(this.selectedSlot.toTime).getHours()) {
      totalMin = new Date(this.selectedSlot.toTime).getMinutes();
    }
    arrayLength = totalMin - startMin;
    for (let index = 0; index <= arrayLength; index++) {
      let booking = {
        mins: startMin
      };
      if (startMin <= 9) {
        booking = {
          mins: '0' + startMin
        };
      } else {
        booking = {
          mins: startMin
        };
      }

      result.push(booking);
      startMin++;
    }
    return result;
  }



  secSelection(event) {
    const secs = event.value;
    this.secs = this.secProcessing(secs.secs);
  }

  tosecSelection(event) {
    const secs = event.value;
    this.tosecs = this.secProcessing(secs.secs);
  }

  secProcessing(sec) {
    let startMin: any = 0;
    const totalMin = 59;
    let arrayLength;
    const minutes = [];
    const selectedTime = new Date(this.selectedSlot.fromTime).getSeconds();

    if (selectedTime === sec) {
      startMin = new Date(this.selectedSlot.fromTime).getSeconds();
    }
    arrayLength = totalMin - startMin;
    for (let index = 0; index <= arrayLength; index++) {
      let booking = {
        secs: startMin
      };
      if (startMin <= 9) {
        booking = {
          secs: '0' + startMin
        };
      } else {
        booking = {
          secs: startMin
        };
      }
      minutes.push(booking);
      startMin++;
    }
    return minutes;
  }

  addSlot() {


    this.toDateLess = false;

    let fromtime: any = new Date(this.selectedSlot.fromTime).setHours(this.selectedHours.hours,
      this.selectedMins.mins, this.selectedSens.secs);
    let totime: any = new Date(this.selectedSlot.fromTime).setHours(this.selectedtoHours.hours,
      this.selectedtoMins.mins, this.selectedtoSens.secs);
    fromtime = this.date.transform(fromtime, 'yyyy-MM-dd HH:mm:ss');
    totime = this.date.transform(totime, 'yyyy-MM-dd HH:mm:ss');
    const postObj = {
      fromTime: fromtime,
      toTime: totime

    };

    console.log(postObj.toTime < postObj.fromTime);

    if (postObj.toTime < postObj.fromTime) {
      this.toDateLess = true;
    } else {
      this.httpService.bookSlot(postObj, this.selectedPlan).subscribe(
        (res) => {
          this.toDateLess = false;
          this.displayBasic = false;
          Swal.fire({
            text: 'Slot booked successfully',
            // tslint:disable-next-line: max-line-length
            imageUrl: 'https://banner2.cleanpng.com/20180601/ush/kisspng-stranahan-theater-booked-cinema-maumee-indoor-thea-fully-booked-5b119c0285c691.372962371527880706548.jpg',
            imageWidth: 400,
            imageHeight: 200,
            imageAlt: 'Custom image',
          });
        }
      );
    }

  }

}

export interface Sales {
  planDetails: PlanDetails[];
}

export interface PlanDetails {
  planId: number;
  fromTime: Date;
  toTime: Date;
  planType: string;
}

export interface GetSlots {

  statusCode: number;
  slotDetails: [];

}



export interface SlotDetails {
  slotId: number;
  fromTime: Date;
  toTime: Date;
  status: string;
}

