import { Component, OnInit, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpserviceService } from '../../services/httpservice.service';
import { DatePipe } from '@angular/common';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css'],
  providers: [DatePipe]
})
export class AdminComponent implements OnInit {
  planList;
  addSlot = false;
  fromDate: Date;
  fromTime: Date;
  toTime: Date;
  minimumDate = new Date();
  planForm: FormGroup;
  loader: false;
  checkFromDate = [];
  checkToDate = [];
  constructor(
    private elementRef: ElementRef,
    private formBuilder: FormBuilder,
    private router: Router,
    private datepipe: DatePipe,
    public httpService: HttpserviceService
  ) { }

  /*
   * @param
   * Get login form controll access
   */
  get plan() {
    return this.planForm.controls;
  }

  getAllPlans() {
    this.httpService.getPlans().subscribe(res => {
      console.log(res);
      this.planList = res.planDetails;
      res.planDetails.forEach(childObj => {
        this.checkFromDate.push(childObj.fromTime);
        this.checkToDate.push(childObj.toTime);
      });
    }
    );
  }

  addNewPlan() {
    this.addSlot = true;
    this.planForm.reset();
    console.log(this.checkFromDate);
    console.log(this.checkToDate);
  }

  submitPlan() {
    if (this.planForm.valid) {
      const letransformdate = this.datepipe.transform(this.planForm.value.fromDate, 'yyyy-MM-dd');
      const letransformTime = this.datepipe.transform(this.planForm.value.fromTime, 'HH:mm:ss');
      const letransToTime = this.datepipe.transform(this.planForm.value.toTime, 'HH:mm:ss');

      const checkFromDate = this.checkFromDate.includes(letransformdate + ' ' + letransformTime);
      const checkToDate = this.checkToDate.includes(letransformdate + ' ' + letransToTime);
      if (checkFromDate === true || checkToDate === true) {
        this.addSlot = false;
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Plan already booked in this slot',
        });
      } else {
        console.log('called');
        const postObj = {
          fromTime: letransformdate + ' ' + letransformTime,
          toTime: letransformdate + ' ' + letransToTime,
          planType: this.planForm.value.planType
        };
        console.log(postObj);
        // tslint:disable-next-line: deprecation
        this.httpService.planSubmit(postObj).subscribe(user => {
          console.log(user);
          this.loader = false;
          this.addSlot = false;
          this.getAllPlans();
          Swal.fire({
            text: 'Plan booked successfully',
            // tslint:disable-next-line: max-line-length
            imageUrl: 'https://banner2.cleanpng.com/20180601/ush/kisspng-stranahan-theater-booked-cinema-maumee-indoor-thea-fully-booked-5b119c0285c691.372962371527880706548.jpg',
            imageWidth: 400,
            imageHeight: 200,
            imageAlt: 'Custom image',
          });
        }, error => {
          this.addSlot = false;
          this.loader = false;
        });
      }
    }
  }


  /*
  * @param create form
  * Create form group object for login form
  */
  createPlanForm() {
    this.planForm = this.formBuilder.group({
      fromDate: ['', Validators.required],
      fromTime: ['', Validators.required],
      toTime: ['', Validators.required],
      planType: ['', Validators.required]
    });
  }
  ngOnInit() {
    this.elementRef.nativeElement.ownerDocument.body.style.background = '';
    const userRole = JSON.parse(sessionStorage.getItem('currentUser')).role;
    if (!this.httpService.validUser()) {
      this.router.navigate(['/login']);
    } else {
      this.router.navigate(['/admin']);
      if (userRole === 'ADMIN') {
        this.router.navigate(['/admin']);
      } else {
        this.router.navigate(['/sales']);
      }
    }
    this.createPlanForm();
    this.getAllPlans();
  }

}
