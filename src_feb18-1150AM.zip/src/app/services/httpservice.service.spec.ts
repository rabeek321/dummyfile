import { TestBed, inject } from '@angular/core/testing';

import { HttpserviceService } from './httpservice.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

describe('HttpService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    providers: [HttpserviceService],
    imports: [HttpClientTestingModule]
  }));

  it('should be created', () => {
    const service: HttpserviceService = TestBed.get(HttpserviceService);
    expect(service).toBeTruthy();
  });

  it('should call the get plan services',
    inject([HttpTestingController, HttpserviceService],
      (mockData: HttpTestingController, http: HttpserviceService) => {
        http.getPlans().subscribe(
          (res) => {

          }
        );
      }));

  it('should call the get plan services',
    inject([HttpTestingController, HttpserviceService],
      (mockData: HttpTestingController, http: HttpserviceService) => {
        const getSlot = 1;
        http.getSlot(getSlot).subscribe(
          (res) => {

          }
        );
      }));

  it('should call the get plan services',
    inject([HttpTestingController, HttpserviceService],
      (mockData: HttpTestingController, http: HttpserviceService) => {
        const plandata = {};
        http.planSubmit(plandata).subscribe(
          (res) => {

          }
        );
      }));

  it('should call the get plan services',
    inject([HttpTestingController, HttpserviceService],
      (mockData: HttpTestingController, http: HttpserviceService) => {
        const loginData = {};
        http.checkLogin(loginData).subscribe(
          (res) => {

          }
        );
      }));


  it('should call the get plan services',
    inject([HttpTestingController, HttpserviceService],
      (mockData: HttpTestingController, http: HttpserviceService) => {
        const bookdata = {};
        const bookplanid = 1;
        http.bookSlot(bookdata, bookplanid).subscribe(
          (res) => {

          }
        );
      }));

  it('should call the get plan services',
    inject([HttpTestingController, HttpserviceService],
      (mockData: HttpTestingController, http: HttpserviceService) => {
        const bookdata = {};
        const bookplanid = 1;
        http.bookSlot(bookdata, bookplanid).subscribe(
          (res) => {

          }
        );
      }));

  it('should check the user',
    () => {
      const user = JSON.parse(sessionStorage.getItem('currentUser'));
      const service: HttpserviceService = TestBed.get(HttpserviceService);
      expect(service.validUser()).toBeTruthy();
    });

  it('should check if not valid user',
    () => {
      const service: HttpserviceService = TestBed.get(HttpserviceService);
      const user = false;
      sessionStorage.clear();
      console.log(service.validUser());
      expect(service.validUser()).toBeFalsy();
    });

});
